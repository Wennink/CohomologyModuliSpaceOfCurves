# -*- coding: utf-8 -*-

from sage.features import PythonModule

psutil_feature = PythonModule("psutil")
