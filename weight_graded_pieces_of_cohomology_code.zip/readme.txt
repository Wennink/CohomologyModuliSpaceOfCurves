This contains an old version of admcycles together with the code.
We plan to integrate the code into admcycles.


To run the code, sagemath needs to be installed.
Extract the zip file and run sage in the same folder.
Run the following command:

from admcycles import *

Now you can use the functions ``compute_weight_graded_pieces`` and ``hodge_serre_poly``.

Note that the ``hodge_serre_poly`` function expects ``compute_weight_graded_pieces`` to have already been called.

For example one can call

compute_weight_graded_pieces([(1,2,None,0)])
hodge_serre_poly(1,2)

One can see a description of the functions by calling them with a question mark appended.
